package server;

import server.mapper.MappedContext;
import server.mapper.MappedHost;
import server.mapper.MappedService;
import server.mapper.MappedWrapper;

import java.io.InputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class RequestProcessorServer extends Thread {

    private Socket socket;
    private MappedService service;

    public RequestProcessorServer(Socket socket, MappedService service) {
        this.socket = socket;
        this.service = service;
    }

    @Override
    public void run() {
        try {
            InputStream inputStream = socket.getInputStream();

            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            Response response = new Response(socket.getOutputStream());


            String url = request.getUrl();  // /demo1/lagou
            ArrayList<Integer> indexList = indexList(url, "/");
            //List<String> urls = Arrays.asList(url.split("/"));
            List<MappedHost> mappedhosts = service.mappedhosts;
            //String url = request.getUrl();
            //http://localhost:8080/demo/lagou

            if (!"/favicon.ico".equals(url)) {   //排除图标异常
                //处理程序
                for (MappedHost host : mappedhosts) {
                    if (request.getDomain().equals(host.name)) {
                        List<MappedContext> mappedContexts = host.mappedContexts;

                        for (MappedContext context : mappedContexts) {
                            // /demo
                            String path = url.substring(indexList.get(0), indexList.get(1));
                            if (context.path.equals(path)) {
                                List<MappedWrapper> mappedWrappers = context.mappedWrappers;
                                //是静态资源吗
                                boolean isStatic = true;
                                for (MappedWrapper mappedWrapper : mappedWrappers) {
                                    // /lagou
                                    String urlpatten = url.substring(indexList.get(1));
                                    if (urlpatten.equals(mappedWrapper.name)) { //
                                        HttpServlet servlet = mappedWrapper.servlet;
                                        servlet.service(request, response);
                                        isStatic = false;
                                        break;
                                    }
                                }
                                if (isStatic) { //都没有匹配到时静态资源
                                    String urlpatten = url.substring(indexList.get(1));
                                    String surl = String.format("%s/%s%s", host.appBase, context.docBase,urlpatten);
                                    //response.outputHtml(request.getUrl());
                                    response.outputHtml(surl);
                                }
                            }

                            if (context.path.equals(path)) {
                                break;
                            }
                        }
                    }
                    if (request.getDomain().equals(host.name)) {
                        break;
                    }
                }
            }
            socket.close();

        }catch (Exception e) {
            e.printStackTrace();
        }

    }


    public ArrayList<Integer> indexList(String str,String split) {
        ArrayList<Integer> indexList = new ArrayList<>();
        int len = str.length();
        for (int i = 0; i < len; i++) {
            String temp = str.charAt(i) + "";
            if (temp.equals(split)) {
                indexList.add(i);
            }
        }
        return indexList;
    }
}
