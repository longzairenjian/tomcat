package server.loader;

import server.HttpServlet;
import server.Request;
import server.Response;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author: joker
 * @description: class 加载工具
 */
public class LoaderUtil {

    /**
     * @param path  字节码文件目录，包的根目录,jar包文件绝对路径
     * @param clazzStr  类全名，包括包名
     * @return
     */
    public static Class loadClass(String path , String clazzStr){
        try{
            //如果路径不是以 \ 或者 / 结尾
            if(!(path.endsWith("\\") || path.endsWith("/"))){
                path = path+"/";
            }
            //String path = "file:D:\\lagou_java\\homework\\Minicat\\webapps\\demo1\\";
            URL newurl=new URL("file:" + path);
            URLClassLoader classLoader=new URLClassLoader(new URL[]{newurl});
            // server.Demo1Servlet
            Class<?> cls = classLoader.loadClass(clazzStr);
            return cls;
            /*HttpServlet servlet = (HttpServlet)cls.newInstance();
            Request request = new Request();
            Response response = new Response();
            servlet.service(request,response);*/
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    //测试
    public static void main(String[] args) throws Exception {
//        Class aClass = loadClass("D:\\lagou_java\\homework\\Minicat\\webapps\\demo1\\server", "Demo1Servlet");
//        HttpServlet servlet = (HttpServlet)aClass.newInstance();
//        Request request = new Request();
//        Response response = new Response();
//        servlet.service(request,response);

        /*File file = new File("D:\\lagou_java\\homework\\Minicat\\webapps\\demo1\\server\\Demo1Servlet.class");
        URL url = file.toURI().toURL();
        URLClassLoader loader = new URLClassLoader(new URL[] { url });
        try {
            Class<?> cls = loader.loadClass("Demo1Servlet");
            HttpServlet servlet = (HttpServlet)cls.newInstance();
            Request request = new Request();
            Response response = new Response();
            servlet.service(request,response);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }*/

        String path = "file:D:\\lagou_java\\homework\\Minicat\\webapps\\demo1\\";
        URL newurl=new URL(path);
        URLClassLoader classLoader=new URLClassLoader(new URL[]{newurl});
        Class<?> cls = classLoader.loadClass("server.Demo1Servlet");
        HttpServlet servlet = (HttpServlet)cls.newInstance();
        Request request = new Request();
        Response response = new Response();
        servlet.service(request,response);


    }

}
