package server;

import java.io.IOException;
import java.io.InputStream;

/**
 * 把请求信息封装为Request对象（根据InputSteam输入流封装）
 */
public class Request {

    private String method; // 请求方式，比如GET/POST
    private String url;  // 例如 /,/index.html

    private String domain; //请求域名  local
    private String port; //请求端口  8080

    private InputStream inputStream;  // 输入流，其他属性从输入流中解析出来


    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public Request() {
    }


    // 构造器，输入流传入
    public Request(InputStream inputStream) throws IOException {
        this.inputStream = inputStream;

        // 从输入流中获取请求信息
        int count = 0;
        while (count == 0) {
            count = inputStream.available();
        }

        byte[] bytes = new byte[count];
        inputStream.read(bytes);

        String inputStr = new String(bytes);
        // 获取第一行请求头信息
        String[] split = inputStr.split("\\n");
        String firstLineStr = split[0];  // GET / HTTP/1.1
        String[] strings = firstLineStr.split(" ");

        this.method = strings[0];
        this.url = strings[1];

        String hoststr = split[1];  //Host: localhost:8080
        String[] hostsplit = hoststr.split(" ")[1].split(":");
        this.domain=hostsplit[0].trim();
        this.port = hostsplit[1].trim();

        System.out.println("=====>>method:" + method);
        System.out.println("=====>>url:" + url);
        /*System.out.println("=====>>domain:" + domain);
        System.out.println("=====>>port:" + port);*/


    }
}
