package server.mapper;

import server.HttpServlet;

/**
 * @author: joker
 */
public class MappedWrapper {
    public String name;
    public HttpServlet servlet;
    public MappedWrapper(String name, HttpServlet servlet) {
        this.name = name;
        this.servlet = servlet;
    }
}
