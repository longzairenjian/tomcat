package server.mapper;

import java.util.List;

/**
 * @author: joker
 */
public class MappedService {
    public String port;
    public List<MappedHost> mappedhosts;

    public MappedService(String port,List<MappedHost> mappedhosts) {
        this.port = port;
        this.mappedhosts = mappedhosts;
    }
}
