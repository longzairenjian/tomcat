package server.mapper;

import java.util.List;

/**
 * @author: joker
 */
public class MappedHost {
    public String name;
    public String appBase;
    public List<MappedContext> mappedContexts;

    public MappedHost(String name, String appBase, List<MappedContext> mappedContexts) {
        this.name = name;
        this.appBase = appBase;
        this.mappedContexts = mappedContexts;
    }
}
