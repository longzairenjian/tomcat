package server.mapper;

import java.util.List;

/**
 * @author: joker
 */
public class MappedContext {
    public List<MappedWrapper> mappedWrappers;
    public  String path;
    public  String docBase;

    public MappedContext(String path,String docBase,List<MappedWrapper> mappedWrappers) {
        this.mappedWrappers = mappedWrappers;
        this.path = path;
        this.docBase=docBase;
    }
}
